#pragma once
#include "entity.h"
class player :
    public entity
{
private:

public:
    player();
    ~player();
};

