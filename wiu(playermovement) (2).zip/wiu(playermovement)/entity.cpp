#include "entity.h"

//entity getters
entity::entity() {

}

entity::~entity() {

}

int entity::getPosX()
{
	return posX;
}

int entity::getPosY()
{
	return posY;
}

//setters
void entity::setPosX(int getX)
{
	posX = getX;
}

void entity::setPosY(int getY)
{
	posY = getY;
}

void entity::move(int moveX, int moveY)
{
	setPosX(getPosX() + moveX);
	setPosY(getPosY() + moveY);
}

