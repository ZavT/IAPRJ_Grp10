#include <iostream>
#include "worldMap.h"
#include "game.h"
int main() {
	game MainGame;
	MainGame.Run();
	return 0;
}