#pragma once
class worldMap
{
public:
    //worldMap();
    //void createworldmap();
};

