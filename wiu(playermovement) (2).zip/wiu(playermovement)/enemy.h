#pragma once
#include "entity.h"
class enemy :
    public entity
{
};

