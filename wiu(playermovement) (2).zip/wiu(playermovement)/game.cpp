#include "game.h"
#include "worldMap.h"
#include <iostream>
#include <conio.h>
#include "player.h"

#define KEY_ARROW_UP 72
#define KEY_ARROW_DOWN 80
#define KEY_ARROW_LEFT 75
#define KEY_ARROW_RIGHT 77

#define ESC "\033"
#define RESET   ESC "[0m"
#define BRIGHT_BLUE    ESC "[94m"
#define BOLD      ESC "[1m"

void game::Run() {
    //instantiating objects
	game world;
    game Bunker;
	bool isRunning = true;

    initmap();
    Player.setPosX(0);
    Player.setPosY(0);

    setpos(7, 0, 'B');
    setpos(Player.getPosX(), Player.getPosY(), 'P');

	while (isRunning) {
        std::cout << "Player Position (X,Y): " << Player.getPosX() << ", " << Player.getPosY() << std::endl;

    	printmap();

        std::cout << "move with arrow keys now" << std::endl;

		int ch = _getch();

        if (ch == 0 || ch == 224) {
            ch = _getch(); // Read the second byte to find the specific arrow

            switch (ch) {
            case KEY_ARROW_UP:
                system("CLS");
                std::cout << "Up Arrow Pressed\n";
                Player.move(0, -1);
                break;
            case KEY_ARROW_DOWN:
                system("CLS");
                std::cout << "Down Arrow Pressed\n";
                Player.move(0, 1);
                break;
            case KEY_ARROW_LEFT:
                system("CLS");
                std::cout << "Left Arrow Pressed\n";
                Player.move(-1, 0);
                break;
            case KEY_ARROW_RIGHT:
                system("CLS");
                std::cout << "Right Arrow Pressed\n";
                Player.move(1, 0);
                break;
            }
        }
        else if (ch == 'q' || ch == 'Q') {
            system("CLS");
            std::cout << "quitted the program" << std::endl;
            isRunning = false;
        }
        setpos(Player.getPosX(), Player.getPosY(), 'P');
	}
}

//void game::createworldmap()
//{
//	initmap();
//	setpos(7, 0, 'B');
//}

void game::initmap() {
    for (int i = 0; i < cols; i++) {
        for (int x = 0; x < rows; x++) {
            maps[i][x] = '?';
        }
    }
}

void game::setpos(int setX, int setY, char symbol) {
    maps[setY][setX] = symbol;
}

void game::printmap() {
    for (int i = 0; i < cols; i++) {
        std::cout << "          "; // spaces before the row
        for (int x = 0; x < rows; x++) {
            if (maps[i][x] == 'B') {
                std::cout << BOLD << BRIGHT_BLUE << maps[i][x] << RESET << " ";
            }
            else if (maps[i][x] == 'P') {
                std::cout << BOLD << BRIGHT_BLUE << maps[i][x] << RESET << " ";
            }
            else {
                std::cout << maps[i][x] << " "; //adds space between dots
            }

        }
        std::cout << std::endl;
    }
}