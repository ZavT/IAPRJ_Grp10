#pragma once
class entity
{
private:
	int posX, posY;
	char symbol;
public: 
	entity();
	~entity();
	
	//getters
	int getPosX();
	int getPosY();

	//setters
	void setPosX(int getX);
	void setPosY(int getY);

	//other functions
	void move(int moveX, int moveY);
	//void setpos(int setX, int setY, char sym); //initiating initial positions
};

