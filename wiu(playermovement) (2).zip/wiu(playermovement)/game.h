#pragma once
#include "player.h"
class game
{
private:
	int rows = 20;
	int cols = 15;
	char maps[30][30];
	player Player;
public:
	void Run();

	void initmap();
	void printmap();
	//void createworldmap();
	void setpos(int setX, int setY, char symbol);
};

