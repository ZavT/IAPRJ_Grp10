#include "map.h"
//#define ESC "\033"
//#define RESET   ESC "[0m"
//#define BRIGHT_BLUE    ESC "[94m"
//#define BOLD      ESC "[1m"
//#include <iostream>
//
//map::map(int r, int c){
//	rows = r;
//	cols = c;
//}
//
//void map::initmap(){
//	for (int i = 0; i < rows; i++) {
//		for (int x = 0; x < cols; x++) {
//			maps[i][x] = '?';
//		}
//	}
//}
//
//void map::setpos(int setX, int setY, char symbol){
//	maps[setX][setY] = symbol;
//}
//
//void map::printmap(){
//	for (int i = 0; i < rows; i++) {
//		std::cout << "          "; // spaces before the row
//		for (int x = 0; x < cols; x++) {
//			if (maps[i][x] == 'B'){
//				std::cout << BOLD << BRIGHT_BLUE << maps[i][x] << RESET << " ";
//			}
//			else if (maps[i][x] == 'P') {
//				std::cout << maps[i][x] << " ";
//			}
//			else {
//				std::cout << maps[i][x] << " "; //adds space between dots
//			}
//
//		}
//		std::cout << std::endl;
//	}
//}
//
//	