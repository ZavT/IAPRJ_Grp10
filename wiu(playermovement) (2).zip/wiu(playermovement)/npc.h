#pragma once
class npc
{
};

