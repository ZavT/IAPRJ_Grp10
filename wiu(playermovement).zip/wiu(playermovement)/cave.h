#pragma once
#include "map.h"
class cave
{
};

