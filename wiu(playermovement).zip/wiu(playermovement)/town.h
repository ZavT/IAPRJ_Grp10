#pragma once
#include "map.h"
class town
{
};

