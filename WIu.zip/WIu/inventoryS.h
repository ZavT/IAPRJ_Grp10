#pragma once
#include "player.h"

class inventoryS : public player
{

};

