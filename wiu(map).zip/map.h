#pragma once
class map
{
private:
	int rows;
	int cols;
	char maps[30][30];

public: 
	map(int r, int c);

	void initmap();
	void printmap();
	void setpos(int row, int col, char symbol);
};

