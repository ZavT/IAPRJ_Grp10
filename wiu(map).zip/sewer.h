#pragma once
#include "map.h"
class sewer :
    public map
{
};

