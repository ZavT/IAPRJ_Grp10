#pragma once
class entity
{
};

