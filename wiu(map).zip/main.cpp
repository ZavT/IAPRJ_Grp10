#include <iostream>
#include "worldMap.h"
int main() {
	worldMap world;
	world.createworldmap();
	world.printmap();
	return 0;
}