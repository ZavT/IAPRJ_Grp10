#pragma once
#include "map.h"
class game
{
    private:
        map worldMap;

    public:
        game();

        void createWorldMap();
        void Run();
};

