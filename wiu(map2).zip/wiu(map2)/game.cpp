#include "game.h"

//MAP STUFF
game::game() : worldMap(15, 20)
{
}

void game::createWorldMap(){
    worldMap.initmap();

    // World locations
    worldMap.setpos(7, 0, 'B');    // Bunker
    worldMap.setplayerpos(7, 1);
}

void game::Run()
{
    createWorldMap();

    worldMap.printmap();
}
//PLAYER STUFF